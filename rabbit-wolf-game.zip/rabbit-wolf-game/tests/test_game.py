"""Tests for consequences of the rules, not copies of the implementation."""

import unittest

from rabbit_game import evaluate_roles, solve


class RabbitGameTests(unittest.TestCase):
    def test_all_wolf_recursion_and_first_choices(self):
        solutions = solve(2)
        self.assertEqual(solutions[1].payoffs, (1.0,))
        self.assertEqual(solutions[1].paths, {"C": 1.0})
        self.assertEqual(solutions[2].payoffs, (1.0, 1.0))
        self.assertEqual(solutions[2].paths, {"CC": 1.0})

    def test_last_living_rabbit_can_escape_on_its_turn(self):
        # In LCLC, the first wolf eats one of two rabbits. If rabbit 4
        # dies, rabbit 2 escapes before wolf 3 acts. Otherwise wolf 3 eats.
        self.assertEqual(evaluate_roles("LCLC"), (1.0, 0.5, 0.5, 0.0))

    def test_rabbit_whose_turn_passed_cannot_escape_later(self):
        # In CLC, if wolf 2 eats rabbit 3, rabbit 1 cannot act again.
        self.assertEqual(evaluate_roles("CLC"), (0.0, 1.0, 0.5))

    def test_tie_represents_both_paths(self):
        solutions = solve(5)
        for n, outcome in solutions.items():
            if n == 0:
                continue
            self.assertAlmostEqual(sum(outcome.paths.values()), 1.0)
            self.assertTrue(all(len(path) == n for path in outcome.paths))
            self.assertTrue(all(0 <= payoff <= 1 for payoff in outcome.payoffs))


if __name__ == "__main__":
    unittest.main()
