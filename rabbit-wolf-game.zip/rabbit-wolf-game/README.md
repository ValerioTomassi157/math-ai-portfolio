# The Rabbit and Wolf Game

A small game theory project in Python. Players declare, in order, whether they
are rabbits (`C`, *conigli*) or wolves (`L`, *lupi*). A wolf can eat one living
rabbit on its turn and wins if it eats. Living rabbits win if they escape;
eaten rabbits and hungry wolves lose. If everyone declares wolf, player 1 dies
and the remaining players play again from the start.

The program computes expected win probabilities using backward induction over
the declaration choices. It uses only the Python standard library.

## Run

```bash
python rabbit_game.py --max-n 5
python -m unittest discover -s tests -v
```

`--max-n` also works with other positive values. The number of declaration
branches grows exponentially, so start small.

## Model used by the solver

1. Every player sees the earlier declarations and knows the rules and other
   players' strategies. Each chooses a declaration that maximizes their own
   probability of winning (**A0**).
2. After declarations, the players who are still alive act in order. A rabbit
   frees all living rabbits on its turn if it is the last *living rabbit in the
   turn order*. A rabbit whose turn has passed cannot act again. A dead rabbit
   has no turn.
3. When a wolf has several living rabbits to eat, the solver assumes it picks
   uniformly at random. This is an **extra modeling assumption**: the stated
   rules require it to eat a rabbit but do not specify how it chooses one.
4. In a tie between declarations, the solver follows the supplied script's
   *proxy* for the vengeance axiom (**V**): if the player's own payoff is below
   1, choose the branch with the smaller sum of expected payoffs for earlier
   players. The script does not identify which earlier players actually caused
   a decrease. If the two sums tie, or if the player's own payoff is 1, it
   assigns equal probability to both declarations.
5. For an all-wolf declaration, the first player loses and the remaining
   players begin a new declaration game. The solver reuses the result for
   `n-1` players.

The output shows each player's **expected probability of winning** and the
probabilities of the declaration sequences. These sequences describe the
first declaration phase: if all players declare wolf, a subsequent game takes
place and its payoffs are already included. A `0.5` probability reflects the
tie rule in item 4, not a random choice of prey.

## Why keep the original script?

[`legacy/original_solver.py`](legacy/original_solver.py) is the code supplied
for this project. It is preserved so the modeling choices can be compared.
The main solver makes one substantive correction: if the last declared rabbit
is eaten before its turn, a different surviving rabbit can be the last living
rabbit **when its turn arrives**. The original script always triggers escape
at the turn of the last *declared* rabbit, even if that rabbit is dead. For
example, for declarations `LCLC`, the main solver produces expected payoffs
`(1, 0.5, 0.5, 0)`; the original produces `(1, 0, 1, 0)`.

The legacy script also prints one representative sequence when its payoffs
are a mixture of several sequences. The main solver reports each sequence
with its probability.

## Project layout

```text
rabbit-wolf-game/
├── README.md                 # Problem, assumptions, and instructions
├── rabbit_game.py            # Main solver and command line interface
├── tests/test_game.py        # Checks for nontrivial game rules
├── legacy/original_solver.py # Original script, unchanged
└── .gitignore
```

## Open questions

The original wording of the game leaves room for different formalizations.
In particular, the prey choice could instead be a strategic decision by each
wolf, and "last rabbit" could be defined differently. The vengeance axiom
also needs a precise definition of **which players caused a loss** before it
can be implemented literally. This repository states its assumptions so that
these variants can be studied without silently changing the rules.
