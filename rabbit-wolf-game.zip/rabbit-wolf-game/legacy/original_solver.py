def print_payoffs(n, path, payoffs):
    formatted_payoffs = [round(p, 3) for p in payoffs]
    print(f"n={n} | Percorso: {path} | Payoff: {formatted_payoffs}")

def evaluate_leaf(roles):
    n = len(roles)
    
    # 1. Trova il turno dell'ultimo coniglio
    last_c_index = -1
    for i in range(n):
        if roles[i] == 'C':
            last_c_index = i
            
    # Stato: dizionario { (tupla_conigli_vivi): probabilità }
    initial_c_tuple = tuple(i for i, r in enumerate(roles) if r == 'C')
    states = {initial_c_tuple: 1.0}
    payoffs = [0.0] * n
    
    # 2. Simulazione dei turni
    for t in range(n):
        # A. Trigger Fuga (anche se l'ultimo C è morto)
        if t == last_c_index:
            new_states = {}
            for alive_cs, prob in states.items():
                for c_idx in alive_cs:
                    payoffs[c_idx] += prob # I conigli vivi scappano e vincono
                # I conigli scappati escono dal gioco (la tupla diventa vuota)
                new_states[tuple()] = new_states.get(tuple(), 0.0) + prob
            states = new_states

        # B. Turno del Lupo
        if roles[t] == 'L':
            new_states = {}
            for alive_cs, prob in states.items():
                num_prey = len(alive_cs)
                if num_prey == 0:
                    # Nessuna preda, il lupo rimane affamato (stato invariato)
                    new_states[alive_cs] = new_states.get(alive_cs, 0.0) + prob
                else:
                    # Il lupo si sazia
                    payoffs[t] += prob
                    prob_per_prey = prob / num_prey
                    # Ramificazione probabilistica: chi viene mangiato?
                    for prey in alive_cs:
                        new_alive = tuple(c for c in alive_cs if c != prey)
                        new_states[new_alive] = new_states.get(new_alive, 0.0) + prob_per_prey
            states = new_states

    return payoffs

def solve_game_up_to(max_n):
    # Memorizza le soluzioni ottimali per ogni n (serve per la regola All-L)
    optimal_payoffs = {0: []}
    
    for n in range(1, max_n + 1):
        prev_game_payoffs = optimal_payoffs[n - 1]
        
        def dfs(prefix):
            # Caso Base: foglia raggiunta
            if len(prefix) == n:
                if all(r == 'L' for r in prefix):
                    return [0.0] + prev_game_payoffs, prefix
                else:
                    return evaluate_leaf(prefix), prefix
            
            d = len(prefix) # Giocatore di turno
            
            ev_C, path_C = dfs(prefix + ['C'])
            ev_L, path_L = dfs(prefix + ['L'])
            
            my_ev_C = ev_C[d]
            my_ev_L = ev_L[d]
            
            eps = 1e-7 # Tolleranza per i float
            
            # Assioma A0: Massimizzazione
            if my_ev_C > my_ev_L + eps:
                return ev_C, path_C
            elif my_ev_L > my_ev_C + eps:
                return ev_L, path_L
            else:
                # PAREGGIO: Valutazione Assioma V (Vendetta)
                if abs(my_ev_C - 1.0) < eps:
                    # Nessuna diminuzione di payoff. Nessuna vendetta. Mix 50/50.
                    mixed_ev = [(c + l) / 2.0 for c, l in zip(ev_C, ev_L)]
                    return mixed_ev, path_C # path_C è usato come rappresentante logico
                else:
                    # C'è stata diminuzione. Scatta Assioma V.
                    # Minimizza la somma dei payoff dei giocatori precedenti.
                    sum_prev_C = sum(ev_C[:d])
                    sum_prev_L = sum(ev_L[:d])
                    
                    if sum_prev_C < sum_prev_L - eps:
                        return ev_C, path_C
                    elif sum_prev_L < sum_prev_C - eps:
                        return ev_L, path_L
                    else:
                        # Pareggio anche sulla vendetta. Mix 50/50.
                        mixed_ev = [(c + l) / 2.0 for c, l in zip(ev_C, ev_L)]
                        return mixed_ev, path_C

        final_ev, best_path = dfs([])
        optimal_payoffs[n] = final_ev
        print_payoffs(n, best_path, final_ev)

# Esegui l'algoritmo per N da 1 a 6
solve_game_up_to(6)
