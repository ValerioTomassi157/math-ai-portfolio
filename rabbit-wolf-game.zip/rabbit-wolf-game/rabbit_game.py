"""Backward induction for the sequential rabbit and wolf game.

This is an explicit model of the assumptions in README.md. In particular, a
wolf's choice of prey is uniform random; this is an assumption, not a rule
specified by the original game.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass


@dataclass
class Outcome:
    """Expected win probabilities and equilibrium declaration probabilities."""

    payoffs: tuple[float, ...]
    paths: dict[str, float]


def evaluate_roles(roles: str) -> tuple[float, ...]:
    """Expected payoffs after declarations, except for the all-wolf case.

    At a rabbit's turn, it frees all living rabbits if no later rabbit is
    alive. Wolves choose uniformly among living rabbits. A rabbit whose turn
    has passed does not receive another turn.
    """
    if not roles or any(role not in "CL" for role in roles):
        raise ValueError("roles must be a nonempty string containing only C and L")
    if "C" not in roles:
        raise ValueError("all-wolf declarations use the recurrence in solve()")

    n = len(roles)
    initial_rabbits = tuple(i for i, role in enumerate(roles) if role == "C")
    states: dict[tuple[int, ...], float] = {initial_rabbits: 1.0}
    payoffs = [0.0] * n

    for turn, role in enumerate(roles):
        if role == "C":
            next_states: dict[tuple[int, ...], float] = {}
            for alive, probability in states.items():
                if turn in alive and not any(rabbit > turn for rabbit in alive):
                    for rabbit in alive:
                        payoffs[rabbit] += probability
                    key: tuple[int, ...] = ()
                else:
                    key = alive
                next_states[key] = next_states.get(key, 0.0) + probability
            states = next_states
        else:
            next_states = {}
            for alive, probability in states.items():
                if not alive:
                    next_states[alive] = next_states.get(alive, 0.0) + probability
                    continue
                payoffs[turn] += probability
                for victim in alive:
                    survivors = tuple(rabbit for rabbit in alive if rabbit != victim)
                    next_states[survivors] = (
                        next_states.get(survivors, 0.0) + probability / len(alive)
                    )
            states = next_states

    return tuple(payoffs)


def _mix(left: Outcome, right: Outcome) -> Outcome:
    paths = {path: probability / 2 for path, probability in left.paths.items()}
    for path, probability in right.paths.items():
        paths[path] = paths.get(path, 0.0) + probability / 2
    return Outcome(tuple((a + b) / 2 for a, b in zip(left.payoffs, right.payoffs)), paths)


def _choose(left: Outcome, right: Outcome, player: int, tolerance: float) -> Outcome:
    """A0, followed by the original script's operational proxy for V."""
    own_left, own_right = left.payoffs[player], right.payoffs[player]
    if own_left > own_right + tolerance:
        return left
    if own_right > own_left + tolerance:
        return right

    # The original code applies vengeance only when the tied payoff is below 1.
    # It uses the sum of earlier players' payoffs as a proxy for 'those who
    # caused the decrease'; the actual causes are not tracked by this model.
    if abs(own_left - 1.0) < tolerance:
        return _mix(left, right)
    earlier_left = sum(left.payoffs[:player])
    earlier_right = sum(right.payoffs[:player])
    if earlier_left < earlier_right - tolerance:
        return left
    if earlier_right < earlier_left - tolerance:
        return right
    return _mix(left, right)


def solve(max_n: int, tolerance: float = 1e-9) -> dict[int, Outcome]:
    """Solve all games from 1 to max_n by backward induction."""
    if max_n < 1:
        raise ValueError("max_n must be positive")
    if tolerance <= 0:
        raise ValueError("tolerance must be positive")

    solutions: dict[int, Outcome] = {0: Outcome((), {"": 1.0})}
    for n in range(1, max_n + 1):
        previous_payoffs = solutions[n - 1].payoffs

        def search(prefix: str) -> Outcome:
            if len(prefix) == n:
                if "C" not in prefix:
                    # Player 1 dies, and the remaining players enter the
                    # solved (n-1)-player game with a fresh declaration phase.
                    return Outcome((0.0,) + previous_payoffs, {prefix: 1.0})
                return Outcome(evaluate_roles(prefix), {prefix: 1.0})

            player = len(prefix)
            as_rabbit = search(prefix + "C")
            as_wolf = search(prefix + "L")
            return _choose(as_rabbit, as_wolf, player, tolerance)

        solutions[n] = search("")
    return solutions


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-n", type=int, default=5, help="largest number of players (default: 5)")
    args = parser.parse_args()

    for n, outcome in solve(args.max_n).items():
        if n == 0:
            continue
        probabilities = ", ".join(f"{value:.3f}" for value in outcome.payoffs)
        print(f"n={n} | win probabilities: ({probabilities})")
        for path, probability in sorted(outcome.paths.items()):
            print(f"  {path}: {probability:.3f}")


if __name__ == "__main__":
    main()
